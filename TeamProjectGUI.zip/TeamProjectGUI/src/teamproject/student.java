/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package teamproject;

/**
 *
 * @author OscarDuarte
 */
public class student {
    public String fName, lName, username;
    public int id,test1, test2, test3;
    public float gpa;
    
    public student(String fName, String lName, int id, int test1, int test2, int test3){
        this.fName = fName;
        this.lName = lName;
        this.id = id;
        this.test1 = test1;
        this.test2 = test2;
        this.test3 = test3;
        this.username = lName + fName.charAt(0);      
    }
}
