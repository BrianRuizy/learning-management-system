package teamproject;

import java.util.ArrayList;

/**
 *
 * @author OscarDuarte
 */
public class admin {
    public String name = "admin";
    public int password = 123;
    ArrayList<student> students = new ArrayList<>();
}
