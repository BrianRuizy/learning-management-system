package teamproject;
import java.util.Vector;
import java.util.Scanner;

/**
 *
 * @author OscarDuarte
 */


public class Admin {
    Scanner in = new Scanner(System.in);
    
    String adminName = "admin";
    int ID = 123;
    Vector<Student> students = new Vector<>();
    
    //****************
    //Add new student*
    //****************
    public void addStudent(){
        Student tempStudent = new Student();
        int courses;
        
        System.out.print("Enter student name (first last): ");
        tempStudent.name = in.nextLine();
        
        System.out.print("Enter student ID: ");
        tempStudent.ID = in.nextInt();
        
        System.out.println();
        
        if(!studentExists(tempStudent.name, tempStudent.ID)){
            for(int i = 0; i < 4; i++){           
                for(int j = 1; j < 4; j++){
                    if(j == 1){
                        System.out.print("Enter course name: ");
                        in.nextLine();
                        tempStudent.courses[i][j-1] = in.nextLine();
                    }
                
                    System.out.print("Enter test " + j + ": ");
                    tempStudent.courses[i][j] = in.nextInt();
                }
                
                System.out.println();//BLANK
            }
            
            tempStudent.calcGPA(tempStudent);
            this.students.add(tempStudent);
            System.out.print("Student has been added...");
            
            in.nextLine();
            System.out.println("-------------------------------------------\n");
        }
        else{
            System.out.println("Student already exists...");
            System.out.println("-------------------------------------------\n"); 
            in.nextLine();
        }
        
    }
    
    //**********************
    //Edit existing student*
    //**********************
    public void editStudent(){   
        String tempName;
        int tempID;
        
        System.out.println("Enter student's name: ");
        tempName = in.nextLine();
        System.out.println("Enter student's ID");
        tempID = in.nextInt();
        
        
        
        System.out.println("-------------------------------------------\n");
    }
    
    //*************************
    //View student information*
    //*************************
    public void viewStudent(){
        String tempName; 
        int tempID;
        boolean exists = false;
               
        if(students.isEmpty()){
            System.out.println("There are currently no students...");          
        }
        else{
            System.out.print("Enter student's name: ");
            tempName = in.nextLine();
        
            System.out.print("Enter student's ID: ");
            tempID = in.nextInt();
        
            in.nextLine();
            System.out.println();//BLANK
        
            for(int i = 0; i < students.size(); i ++){
                if(students.get(i).exists(tempName, tempID)){
                    exists = true;
                
                    students.get(i).studentInfo();
                    break;
                }
            }

            if(exists == false){
                System.out.println("Account not found...");
            }      
        }
        
        System.out.println("-------------------------------------------\n");
    }
    
    //************************
    //Check if Student exists*
    //************************
    public boolean studentExists(String name, int ID){
        boolean sExists = false;
        
        for(int i = 0; i < students.size(); i ++){
            if(students.get(i).exists(name, ID)){
                sExists = true;
                break;
            }
        }
        
        return sExists;
    }
}
