package teamproject;
import java.util.Scanner;
import java.io.*;

/**
 *
 * @author OscarDuarte
 */
public class TeamProject {
    //First Menu
    public static final int logIn = 1;
    public static final int exit = 0;
    
    //Admin's Menu
    public static final int addStudent = 1;
    public static final int editStudent = 2;
    public static final int viewStudent = 3;
    public static final int exit1 = 0;
    
    //Admin's edit menu
    final static int deleteStudent = 1;
    final static int editCourse = 2;
    final static int editTest = 3;
    
    //Student's Menu
    public static final int viewInfo = 1;
    public static final int exit2 = 0;
    
    public static Scanner in = new Scanner(System.in);
    
    //************
    //MAIN METHOD*
    //************
    public static void main(String[] args) {
        Admin admin = new Admin();
        String name;
        int ID;
        int choice1 = 0;
        int choice2 = 0;
        int editChoice = 0;
        boolean accFound = false;
       
        String fileName;
        
        System.out.print("Enter file name: ");
        fileName = in.next();
        
        try{
            FileReader fileReader = new FileReader(fileName);
        }
        catch(IOException ex){
                
        }
                
        do{ 
            //First Menu
            System.out.println(logIn + ".) Log in");
            System.out.println(exit + ".) Exit");
           
            try{
                System.out.print("Enter choice: ");           
                choice1 = in.nextInt();
            }
            catch(Exception e){
                System.out.println("Error...\n");
            }
            
            in.nextLine();
            System.out.println();//BLANK           
            
            switch(choice1){
                case(logIn):{   //Log in 
                    System.out.print("Enter Name: ");
                    name = in.nextLine();
                   
                    System.out.print("Enter ID: ");
                    ID = in.nextInt();
        
                    in.nextLine();
                    System.out.println();//BLANK
        
                    //Admin login
                    if(name.equals(admin.adminName) && ID == admin.ID){
                        accFound = true;
                        do{
                            choice2 = adminMenu(choice2);
                
                            switch(choice2){
                                case(addStudent):{ //Add new Student
                                    admin.addStudent();
                                    break;
                                }
                                case(editStudent):{ //Edit existing student
                                    admin.editStudent();
                                    break;
                                }
                                case(viewStudent):{
                                    admin.viewStudent();
                                    break;
                                }
                                case(exit1):{ //Exit admin menu
                                    System.out.println("Signed out...");
                                    System.out.println("-------------------------------------------\n");
                                    break;
                                }
                            }
                        }while(choice2 != exit1);
                    }
                    else{
                        //Student login                  
                        for(int i = 0; i < admin.students.size(); i++){
                            if(admin.students.get(i).exists(name, ID)){
                                accFound = true;

                                do{
                                    choice2 = studentMenu(name, choice2);

                                    switch(choice2){
                                        case(viewInfo):{ //View student information
                                            admin.students.get(i).studentInfo();
                                            break;
                                        }
                                        case(exit2):{ //Exit student menu
                                            System.out.println("Signed out...");
                                            System.out.println("-------------------------------------------\n");
                                            break;
                                        }
                                    }                               
                                }while(choice2 != exit2);    
                                break;
                            }
                        }                          
                    }
                    
                    if(accFound == false){
                        System.out.println("Account not found...");
                        System.out.println("-------------------------------------------\n");
                    }
                    
                    break;
                }
                case(exit):{ //Exit Program
                    System.out.println("Ending Program...");
                    break;
                }
            }
        }while(choice1 != exit);      
    }
    
    //***********
    //ADMIN MENU*
    //***********
    public static int adminMenu(int choice){
   
            System.out.println("Hello, Admin!");
            System.out.println(addStudent + ".) Add Student");
            System.out.println(editStudent + ".) Edit Student");
            System.out.println(viewStudent + ".) View a Student ");
            System.out.println(exit1 + ".) Exit");
            
            System.out.print("Enter choice: ");
            choice = in.nextInt();
           
            in.nextLine();
            System.out.println();//BLANK
            
            return choice;
    }
    
    //******************
    //Admin's edit menu*
    //******************
    public static void editMenu(int choice){
        
        System.out.println(deleteStudent + "1) Delete Student");
        System.out.println(editTest + "2) Edit a test");
        System.out.println();
    }
    
    //*************
    //STUDENT MENU*
    //*************
    public static int studentMenu(String name, int choice){
       
        System.out.println("Hello, " + name + "!");
        System.out.println(viewInfo + ".) View Information");
        System.out.println(exit2 + ".) Exit");
        
        System.out.print("Enter choice: ");
        choice = in.nextInt();
        
        System.out.println();//BLANK
        
        return choice;
    }
}
