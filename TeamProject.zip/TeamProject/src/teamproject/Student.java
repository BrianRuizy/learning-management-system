package teamproject;

/**
 *
 * @author OscarDuarte
 */
public class Student {
    
    String name;
    int ID;
    Object[][] courses = new Object[4][4];
    double GPA;
    
    //default constructor
    public Student(){
        name = " ";
        ID = 0;
        GPA = 0;
        
        for(int i = 0; i < 4; i++){           
            for(int j = 1; j < 4; j++){
                if(j == 1){
                    courses[i][j-1] = " ";
                }
                
                courses[i][j] = 0;
            }
        }          
    }
    
    //**************
    //Calculate GPA*
    //**************
    public void calcGPA(Student obj){
        int sumCourse;
        int courseGrade;//store course overall grade
        int[] courseGrades = new int[4]; //Store courses' grades
        
        //Calculate each course grade
        for(int i = 0; i < 4; i++){
            sumCourse = 0;
            courseGrade = 0;
            
            for(int j = 1; j < 4; j++){
                sumCourse += (int)courses[i][j];
            }
            
            courseGrade = sumCourse/3;

            courseGrades[i] = courseGrade;
        }
        
        //Calculate GPA based on course grades
        for(int i = 0; i < courseGrades.length; i++){     
        
            if(courseGrades[i] >= 90){
                this.GPA += 4.0;
            }
            else if(courseGrades[i] <= 89 && courseGrades[i] >= 80){
                this.GPA += 3.0;
            }
            else if(courseGrades[i] <= 79 && courseGrades[i] >= 70){
                this.GPA += 2.0;
            }
            else if(courseGrades[i] <= 69 && courseGrades[i] >= 60){
                this.GPA += 1.0;
            }

            if(i == 3){
                this.GPA /= 4;
            }              
        }
    }
    
    //****************************
    //Display student information*
    //****************************
    public void studentInfo(){
        System.out.println("Name: " + name);
        System.out.println("ID: " + ID);
        System.out.println("GPA: " + GPA + "\n");
        
        for(int i = 0; i < 4; i++){
            for(int j = 1; j < 4; j++){
                if(j == 1){
                    System.out.println("Course: " + courses[i][j-1]);
                }
                
                System.out.print("Test " + j + ": " + courses[i][j] + "\t");
            }
            System.out.println("\n");//BLANK
        }
        
    }
    
    
    //************************
    //Check student existence*
    //************************
    public boolean exists(String name, int ID){
        boolean valid = false;
        
        if(this.name.equals(name) && this.ID == ID){
            valid = true;
        }
        
        return valid;
    }
    
}
